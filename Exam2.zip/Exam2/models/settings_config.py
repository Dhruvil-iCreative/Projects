from ast import literal_eval

from odoo import models, fields, api


class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    module_Exam2 = fields.Boolean("Install Contacts")
    sale_order_ids = fields.Many2many('sale.order', string="Sale Order", required=False)

    @api.model
    def get_values(self):
        res = super(ResConfigSettings, self).get_values()
        IrValues = self.env['ir.config_parameter']
        module_Exam2 = IrValues.get_param('Exam2.module_Exam2')
        sale_order_ids = IrValues.get_param('Exam2.sale_order_ids')
        lines = False
        if sale_order_ids:
            print("/*********************************", sale_order_ids)
            print("////////////////////////////////////////", type(sale_order_ids))
            for i in sale_order_ids:
                if i.isnumeric():
                    lines = [(4, i)]
        return {
            'module_Exam2': module_Exam2,
            'sale_order_ids': lines,
        }

    @api.model
    def set_values(self):
        res = super(ResConfigSettings, self).set_values()
        self.env['ir.config_parameter'].set_param(
            'Exam2.module_Exam2', self.module_Exam2)
        self.env['ir.config_parameter'].set_param(
            'Exam2.sale_order_ids', self.sale_order_ids.ids)
        return res


    # @api.onchange('is_checked')
    # def _onchange_is_checked(self):
    #     for rec in self:
    #         if not rec.is_checked:
    #             rec.description = False
    #             rec.company_id = False
